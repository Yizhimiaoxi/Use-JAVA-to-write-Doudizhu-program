package user.DDZ.d;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;

import user.DDZ.a.Chupai;
import user.DDZ.c.Xiaoxi;
import user.DDZ.c.Poker;
import user.DDZ.c.Biaoqian;

public class ChuPaifashe extends Thread{
	
	private int time;
	
	private Chupai mainFrame;
	
	private boolean isRun;
	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public Chupai getMainFrame() {
		return mainFrame;
	}

	public void setMainFrame(Chupai mainFrame) {
		this.mainFrame = mainFrame;
	}

	public boolean isRun() {
		return isRun;
	}

	public void setRun(boolean isRun) {
		this.isRun = isRun;
	}

	public ChuPaifashe(int time,Chupai mainFrame)
	{
		 isRun=true;
		 this.time=time;
		 this.mainFrame=mainFrame;
	}
	
	public  void run()
	{
		  while(time>=0 && isRun)
		  {			   
			     mainFrame.timeLabel.setText(time+"");
			     time--;
			     
			     try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			     
		  }
		  Xiaoxi message=null;
		  if(time==-1 || isRun==false && mainFrame.isOut==false)
		  {

			   mainFrame.chupaiJLabel.setVisible(false);
			   mainFrame.buchuJLabel.setVisible(false);
			   mainFrame.timeLabel.setVisible(false);
			   
			   message=new Xiaoxi(3,mainFrame.currentPlayer.getId(),"����",null);	
			   

				  String msg=JSON.toJSONString(message);
				  mainFrame.sendThread.setMsg(msg);
		  }
		 
		  //����
		  if(isRun==false && mainFrame.isOut==true)
		  {
			  message=new Xiaoxi(4,mainFrame.currentPlayer.getId(),"����",changePokerLableToPoker(mainFrame.selectedPokerLabels));
			  
			 
			  String msg=JSON.toJSONString(message);
			  mainFrame.sendThread.setMsg(msg);
			 
			  mainFrame.removeOutPokerFromPokerList();	
			
			  if(mainFrame.pokerLabels.size()==0)
			  {
				   message=new Xiaoxi(5, mainFrame.currentPlayer.getId(), "��Ϸ����", null);
				   msg=JSON.toJSONString(message);
				   try {
					 Thread.sleep(100);
					 mainFrame.sendThread.setMsg(msg);
				} catch (InterruptedException e) {
				
					e.printStackTrace();
				}
				  
			  }
			
			  
		  }
		  
		
		
		  
	}
	
	public List<Poker> changePokerLableToPoker(List<Biaoqian> selectedPokerLabels)
	{
		     List<Poker> list=new ArrayList<Poker>();
		     for(int i=0;i<selectedPokerLabels.size();i++)
		     {
		    	    Biaoqian pokerLabel=selectedPokerLabels.get(i);
		    	    Poker poker=new Poker(pokerLabel.getId(), pokerLabel.getName(), pokerLabel.getNum());
		    	    list.add(poker);
		     }
		     
		     return list;
	}
	

}
