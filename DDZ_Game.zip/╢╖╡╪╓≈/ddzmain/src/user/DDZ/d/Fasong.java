package user.DDZ.d;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

//����
public class Fasong extends Thread{

	private String msg;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	private Socket socket;
	
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	
	private boolean isRun=true;	
	
	public boolean isRun() {
		return isRun;
	}
	public void setRun(boolean isRun) {
		this.isRun = isRun;
	}
	public Fasong(Socket socket)
	{
		this.socket=socket;
	}
	public Fasong(Socket socket,String msg)
	{
		this.socket=socket;
		this.msg=msg;
	}
	public Fasong()
	{
	}
	public void run()
	{
		DataOutputStream dataOutputStream;
		try {
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			while(true)
			{
				if(isRun==false)
					break;
				//�����Ϣ��Ϊnull 
			  if(msg!=null)
			  {
				 System.out.println("��Ϣ�ڷ�����:"+msg);
				  //������Ϣ
			     dataOutputStream.writeUTF(msg);
			     //���
			     msg=null;			     		    
			  }
			  
			  Thread.sleep(50);  
			
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		} 
		
		
		
	}
	
}
