package user.DDZ.d;

import com.alibaba.fastjson.JSON;

import user.DDZ.a.Chupai;
import user.DDZ.c.Xiaoxi;

//��ʱ��
public class Jilu extends Thread{
	
	private int i;
	
	private Chupai mainFrame;
	
	private boolean isRun;
	
	public boolean isRun() {
		return isRun;
	}

	public void setRun(boolean isRun) {
		this.isRun = isRun;
	}

	public Jilu(int i,Chupai mainFrame)
	{
		  isRun=true;
		  this.i=i;
		  this.mainFrame=mainFrame;
	}
	
	public void run()
	{
		  while(i>=0 && isRun)
		  {
			    mainFrame.timeLabel.setText(i+"");
			    
			    i--;
			    
			    try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		  }
		  
		  Xiaoxi msg=null;
		  //ʱ�䵽�� ���� ��������������İ�ť��		 
		  if(i==-1 || isRun==false && mainFrame.isLord==false)
		  {
			  msg=new Xiaoxi(1,mainFrame.currentPlayer.getId(),"����",null);			
		  }
		  
		  //������
		  if(isRun==false && mainFrame.isLord==true)
		  {
			  msg=new Xiaoxi(2,mainFrame.currentPlayer.getId(),"������",null);	 
			
		  }
		 
		  mainFrame.sendThread.setMsg(JSON.toJSONString(msg));	
		  
	}
	

}
