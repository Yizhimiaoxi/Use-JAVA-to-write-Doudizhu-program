package user.DDZ.a;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Photo extends JPanel{

	public Photo()
	{
		this.setLayout(null);  
	}

	
	protected void paintComponent(Graphics g) {
		Image image;
            image = new ImageIcon("images/bg/bg1.png").getImage();
		
		g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
		
		
	}
	
	   	  
	

}
