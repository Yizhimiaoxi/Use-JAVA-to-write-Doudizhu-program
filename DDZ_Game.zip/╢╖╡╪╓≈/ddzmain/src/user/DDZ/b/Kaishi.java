package user.DDZ.b;

import user.DDZ.c.Biaoqian;

public class Kaishi {	

	public static void move(Biaoqian pokerLabel,int x,int y)
	{
		 pokerLabel.setLocation(x, y);
		 
		 try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	public static void move2(Biaoqian pokerLabel,int x,int y)
	{
		 pokerLabel.setLocation(x, y);
		 
		
	}
	
	
}