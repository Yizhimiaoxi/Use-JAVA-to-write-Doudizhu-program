package user.DDZ.b;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Xiaoxi implements Serializable {
	
	private int typeid; //��Ϣ����
	
	private int playerid; //���id
	
	private String content; //��Ϣ����
	
	private List<Poker> pokers=new ArrayList<Poker>(); //�˿��б�

	public int getTypeid() {
		return typeid;
	}

	public void setTypeid(int typeid) {
		this.typeid = typeid;
	}

	public int getPlayerid() {
		return playerid;
	}

	public void setPlayerid(int playerid) {
		this.playerid = playerid;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<Poker> getPokers() {
		return pokers;
	}

	public void setPokers(List<Poker> pokers) {
		this.pokers = pokers;
	}
	
	public Xiaoxi()
	{
		
	}
	
	public Xiaoxi(int typeid,int playerid,String content,List<Poker> pokers)
	{
		this.typeid=typeid;
		this.playerid=playerid;
		this.content=content;
		this.pokers=pokers;
	}
	
	
	
	

}
