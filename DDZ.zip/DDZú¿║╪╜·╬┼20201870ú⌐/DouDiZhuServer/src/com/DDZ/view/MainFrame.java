package com.DDZ.view;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.crypto.Data;

import com.DDZ.model.Message;
import com.DDZ.model.Player;
import com.DDZ.model.Poker;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class MainFrame {
	
	
	public List<Player> players=new ArrayList<Player>();	
	
	public int index=0;
	
	public List<Poker> allPokers=new ArrayList<Poker>();
	
	//��ŵ���
	public List<Poker> lordPokers=new ArrayList<Poker>();
	
	public int step=0;  
	
	public MainFrame()
	{
		
		createPokers();		
		
		try {
			
			
			ServerSocket serverSocket=new ServerSocket(8888);
			
			while(true)
			{
				
				Socket socket= serverSocket.accept();			
				
				AcceptThread acceptThread=new AcceptThread(socket);
				acceptThread.start();
				
			}
			
		} catch (IOException e) {
			
			
			System.out.println("�������˹ر�");
		}
		
	}
	
	class AcceptThread extends Thread
	{
		Socket socket;
		
		public AcceptThread(Socket socket)
		{
			this.socket=socket;
			
		}
		
		public void run()
		{
			 try {
				DataInputStream dataInputStream=new DataInputStream(socket.getInputStream());
				
				while(true)
				{
					String msg=dataInputStream.readUTF();	
					
					if(step==0)
					{
						
						Player player=new Player(index++,msg);
						player.setSocket(socket);
						
						players.add(player);
						
						System.out.println(msg+"������");
						
						System.out.println("��ǰ��������:"+players.size());
						
						if(players.size()==3)
						{
							  fapai();
							  step=1;
						}
					}
					
					else if(step==1)  
					{
						System.out.println("�Ƿ�������");
						
						JSONObject msgJsonObject=  JSON.parseObject(msg); 
						
						int typeid=msgJsonObject.getInteger("typeid");
						
					    int playerid=msgJsonObject.getInteger("playerid");
					    
					    String content=msgJsonObject.getString("content");
					    					    
					    //������
					    if(typeid==2)
					    {
					    	
					    	Message sendMessage=new Message(typeid,playerid,content,lordPokers);
					    	
					    	msg=JSON.toJSONString(sendMessage);		
					    	
					    	step=2;					    	
					    }
					    
					   //���� 
					    
					    sendMessageToClient(msg);	
					    
					}
					else if(step==2) 
					{
						sendMessageToClient(msg); 
						
					}
					
				}
				
			} catch (IOException e) {
				
				
				System.out.println("�������ر�:"+e.getMessage());
			}
			 
			 
		}
	}
	

	public void sendMessageToClient(String msg)
	{
		for(int i=0;i<players.size();i++)
		{
			   DataOutputStream dataOutputStream;
			try {
				dataOutputStream = new DataOutputStream(players.get(i).getSocket().getOutputStream());
				 dataOutputStream.writeUTF(msg);
			} catch (IOException e) {
			
				e.printStackTrace();
			}
			   
			  
		}
		
	}
	
	
	public void createPokers()
	{		
		//���� ��С��
	    Poker dawang=new Poker(0,"����",17);	
	    Poker xiaowang=new Poker(1,"С��",16);
	    
	    allPokers.add(dawang);
	    allPokers.add(xiaowang);
	    
	    //�����˿�
	    String[] names=new String[]{"2","A","K","Q","J","10","9","8","7","6","5","4","3"};
	    String[] colors=new String[]{"����","����","÷��","˫��"};
	    
	    int id=2;
	    int num=15;
	   
	    for(String name:names)
	    {
	    	
	    	for(String color:colors)
	    	{
	    		Poker poker=new Poker(id++,color+name,num);
	    		
	    		allPokers.add(poker);
	    	}
	    	num--;
	    }	    
	  
	    Collections.shuffle(allPokers);
	}	
	
	public void fapai()
	{
		 
		  for(int i=0;i<allPokers.size();i++)
		  {
			  //������
			   if(i>=51)
			   {
				   lordPokers.add(allPokers.get(i));
			   }
			   else {
				
				   if(i%3==0)
					   players.get(0).getPokers().add(allPokers.get(i));
				   else if(i%3==1)
					   players.get(1).getPokers().add(allPokers.get(i));
				   else
					   players.get(2).getPokers().add(allPokers.get(i));
			}
		  }
		  
		
		  for(int i=0;i<players.size();i++)
		  {
			 try {
				DataOutputStream dataOutputStream=new DataOutputStream(players.get(i).getSocket().getOutputStream());
			
				String jsonString=JSON.toJSONString(players);
				
				dataOutputStream.writeUTF(jsonString);				
				
			 } catch (IOException e) {
				
				e.printStackTrace();
			}
		  
		   
		  }
		
	}
	

	
	

}
